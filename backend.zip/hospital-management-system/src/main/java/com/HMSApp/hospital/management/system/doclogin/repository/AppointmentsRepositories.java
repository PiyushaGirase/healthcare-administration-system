package com.HMSApp.hospital.management.system.doclogin.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.HMSApp.hospital.management.system.doclogin.entity.Appointment;

@Repository
public interface AppointmentsRepositories extends JpaRepository<Appointment, Long> {

}
